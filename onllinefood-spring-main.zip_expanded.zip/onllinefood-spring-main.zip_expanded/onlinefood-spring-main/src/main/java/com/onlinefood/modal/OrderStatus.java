package com.onlinefood.modal;

public enum OrderStatus {
	PAID
}
