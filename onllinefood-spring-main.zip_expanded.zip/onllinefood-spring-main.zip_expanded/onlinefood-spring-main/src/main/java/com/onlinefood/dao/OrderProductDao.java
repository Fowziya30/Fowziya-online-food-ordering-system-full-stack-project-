package com.onlinefood.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlinefood.modal.OrderProduct;

public interface OrderProductDao extends JpaRepository<OrderProduct, Long> {

}
