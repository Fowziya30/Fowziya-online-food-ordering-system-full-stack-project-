package com.onlinefood.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlinefood.modal.Comment;

public interface CommentDao extends JpaRepository<Comment, Long> {

}
